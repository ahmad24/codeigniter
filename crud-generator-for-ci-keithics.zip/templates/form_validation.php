<?php

$config = array(
             	{form_validation_data}
			   );
			   
?>